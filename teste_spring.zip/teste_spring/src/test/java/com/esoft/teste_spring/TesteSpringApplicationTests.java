package com.esoft.teste_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
